// /api/me — baca siapa yang lagi login dari cookie session (buat ditampilin di sidebar).
// Gak query Firestore — cukup verifikasi cookie, karena username udah "nempel" di situ.

const { verifySessionToken, getCookie } = require('../lib/session');

module.exports = async function handler(req, res) {
  const sessionSecret = process.env.SESSION_SECRET;
  if (!sessionSecret) {
    res.status(200).json({ loggedIn: false });
    return;
  }

  const token = getCookie(req, 'snooze_session');
  const session = verifySessionToken(token, sessionSecret);

  if (!session) {
    res.status(200).json({ loggedIn: false });
    return;
  }

  res.status(200).json({ loggedIn: true, username: session.username });
};
