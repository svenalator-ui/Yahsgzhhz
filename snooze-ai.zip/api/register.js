// /api/register — daftar akun baru, disimpan di Firestore.
// Password di-hash (scrypt) sebelum disimpan — gak pernah nyimpen plain text.

const { getDb } = require('../lib/firebase');
const { hashPassword } = require('../lib/password');
const { createSessionCookie } = require('../lib/session');

const RATE_LIMIT_WINDOW_MS = 60 * 60 * 1000; // 1 jam
const RATE_LIMIT_MAX = 5;
const attemptMap = new Map();

function isRateLimited(ip) {
  const now = Date.now();
  const entry = attemptMap.get(ip) || [];
  const recent = entry.filter(t => now - t < RATE_LIMIT_WINDOW_MS);
  recent.push(now);
  attemptMap.set(ip, recent);
  return recent.length > RATE_LIMIT_MAX;
}

const USERNAME_RE = /^[a-zA-Z0-9_.]{3,20}$/;

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const ip = (req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown').split(',')[0].trim();
  if (isRateLimited(ip)) {
    res.status(429).json({ error: 'Kebanyakan percobaan daftar, coba lagi sebentar lagi.' });
    return;
  }

  const sessionSecret = process.env.SESSION_SECRET;
  if (!sessionSecret) {
    res.status(500).json({ error: 'SESSION_SECRET belum diset di Environment Variables Vercel.' });
    return;
  }

  const { username, password } = req.body || {};

  if (typeof username !== 'string' || !USERNAME_RE.test(username)) {
    res.status(400).json({ error: 'Username 3-20 karakter, cuma huruf/angka/underscore/titik.' });
    return;
  }
  if (typeof password !== 'string' || password.length < 6) {
    res.status(400).json({ error: 'Password minimal 6 karakter.' });
    return;
  }

  const usernameKey = username.toLowerCase();

  let db;
  try {
    db = getDb();
  } catch (e) {
    res.status(500).json({ error: e.message });
    return;
  }

  try {
    const userRef = db.collection('users').doc(usernameKey);
    const existing = await userRef.get();
    if (existing.exists) {
      res.status(409).json({ error: 'Username sudah dipakai, coba yang lain.' });
      return;
    }

    await userRef.set({
      username: username,
      passwordHash: hashPassword(password),
      createdAt: Date.now()
    });

    res.setHeader('Set-Cookie', createSessionCookie(username, sessionSecret));
    res.status(200).json({ ok: true, username: username });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Gagal menyimpan akun: ' + err.message });
  }
};
