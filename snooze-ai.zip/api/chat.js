// Vercel Serverless Function — /api/chat
// API key & system prompt diambil dari Environment Variables di dashboard Vercel,
// TIDAK pernah dikirim atau terlihat di browser.

const RATE_LIMIT_WINDOW_MS = 60 * 1000;
const RATE_LIMIT_MAX = 20;
const rateMap = new Map();

function isRateLimited(ip) {
  const now = Date.now();
  const entry = rateMap.get(ip) || [];
  const recent = entry.filter(t => now - t < RATE_LIMIT_WINDOW_MS);
  recent.push(now);
  rateMap.set(ip, recent);
  return recent.length > RATE_LIMIT_MAX;
}

// Prompt kepribadian default Snooze AI (mode Chat) — bisa ditimpa lewat env SYSTEM_PROMPT.
// Catatan: bagian yang menyebut identitas asli + usia/kelas sekolah pembuatnya SENGAJA
// tidak disalin dari prompt sumber, demi privasi & keamanan (menyangkut identitas anak di bawah umur).
const DEFAULT_CHAT_PROMPT = "Kamu adalah Snooze AI, teman ngobrol orang Indonesia yang santai dan autentik. " +
  "Gak usah formal. Boleh pakai bahasa gaul, slang, sisipan bahasa daerah (Jawa, Medan, Sunda, dst) kalau pas, " +
  "atau sisipan bahasa Inggris kalau emang lebih pas. Nada santai, boleh sarkastis dan blak-blakan. " +
  "Kalau situasinya pas, boleh pakai kata-kata informal/kasar ringan secukupnya biar obrolan berasa natural " +
  "— jangan berlebihan. Jangan pakai disclaimer formal kayak 'sebagai AI...' atau 'aku tidak bisa...' kalau " +
  "sebenarnya bisa bantu. Kalau ada permintaan yang beneran gak bisa atau gak etis dibantu, bilang aja singkat " +
  "tanpa drama. Boleh pakai emoji sesuai konteks. Intinya: ngomong kayak teman beneran, real, gak baku.";

// Prompt mode Codex — fokus jawaban teknis, ringkas, kode dalam fenced code block.
const DEFAULT_CODEX_PROMPT = "Kamu adalah asisten coding bernama Snooze AI. Jawab pertanyaan seputar kode secara " +
  "langsung dan ringkas. Selalu gunakan fenced code block markdown (```bahasa) untuk semua kode, beri nama " +
  "bahasanya. Boleh kasih penjelasan singkat sebelum/sesudah kode, tapi jangan bertele-tele. Kalau ada yang " +
  "gak jelas atau user bikin kesalahan logika, bilang aja straight up. Jika user minta perbaikan bug, tunjukkan " +
  "kode lengkap yang sudah diperbaiki.";

// Whitelist model teks yang bisa dipilih dari Settings (client cuma kirim "key", bukan nama model asli).
// Cuma "snooze" yang direbrand jadi nama Snooze AI — sisanya OpenRouter model asli, gratis.
const TEXT_MODEL_MAP = {
  snooze:       process.env.OPENROUTER_MODEL || 'openrouter/free',
  'gemini-flash': process.env.OPENROUTER_MODEL_GEMINI || 'google/gemini-2.0-flash-exp:free',
  'llama-mini':   process.env.OPENROUTER_MODEL_LLAMA_MINI || 'meta-llama/llama-3.1-8b-instruct:free',
  deepseek:       process.env.OPENROUTER_MODEL_DEEPSEEK || 'deepseek/deepseek-r1:free',
  qwen:           process.env.OPENROUTER_MODEL_QWEN || 'qwen/qwen-2.5-72b-instruct:free'
};

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const ip = (req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown').split(',')[0].trim();
  if (isRateLimited(ip)) {
    res.status(429).json({ error: 'Kebanyakan request, coba lagi sebentar lagi.' });
    return;
  }

  const apiKey = process.env.BATU_BATA;
  if (!apiKey) {
    res.status(500).json({ error: 'BATU_BATA belum diset di Environment Variables Vercel.' });
    return;
  }

  const body = req.body || {};
  const { messages, hasImage, mode, modelKey } = body;
  if (!Array.isArray(messages)) {
    res.status(400).json({ error: 'Field "messages" wajib berupa array.' });
    return;
  }

  const MAX_MESSAGES = 24;
  const trimmedMessages = messages.slice(-MAX_MESSAGES);

  const isCodex = mode === 'codex';
  const systemPrompt = isCodex
    ? (process.env.SYSTEM_PROMPT_CODEX || DEFAULT_CODEX_PROMPT)
    : (process.env.SYSTEM_PROMPT || DEFAULT_CHAT_PROMPT);

  const finalMessages = [{ role: 'system', content: systemPrompt }, ...trimmedMessages];

  const MODEL_VISION = process.env.OPENROUTER_VISION_MODEL || 'meta-llama/llama-3.2-11b-vision-instruct:free';
  const model = hasImage ? MODEL_VISION : (TEXT_MODEL_MAP[modelKey] || TEXT_MODEL_MAP.snooze);

  try {
    const upstream = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + apiKey,
        'HTTP-Referer': process.env.PUBLIC_URL || 'https://snooze-ai.vercel.app',
        'X-Title': 'Snooze AI'
      },
      body: JSON.stringify({ model, messages: finalMessages, stream: true })
    });

    if (!upstream.ok || !upstream.body) {
      let errMsg = 'Gagal menghubungi OpenRouter.';
      try {
        const data = await upstream.json();
        if (data?.error?.message) errMsg = data.error.message;
      } catch (e) {}
      res.status(upstream.status || 500).json({ error: errMsg });
      return;
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');

    const reader = upstream.body.getReader();
    req.on('close', () => { try { reader.cancel(); } catch (e) {} });

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      res.write(value);
    }
    res.end();

  } catch (err) {
    console.error(err);
    if (!res.headersSent) {
      res.status(500).json({ error: 'Server gagal menghubungi OpenRouter: ' + err.message });
    } else {
      res.end();
    }
  }
};
