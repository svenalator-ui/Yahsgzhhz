// /api/login — verifikasi akun ke Firestore.
// Setelah cocok, server kasih "tiket" (cookie) berisi username + tanda tangan HMAC,
// dicek ulang oleh middleware.js di setiap request. Tetap stateless — session gak
// disimpan di server, cuma akunnya yang di Firestore.

const { getDb } = require('../lib/firebase');
const { verifyPassword } = require('../lib/password');
const { createSessionCookie } = require('../lib/session');

const RATE_LIMIT_WINDOW_MS = 60 * 1000;
const RATE_LIMIT_MAX = 8;
const attemptMap = new Map();

function isRateLimited(ip) {
  const now = Date.now();
  const entry = attemptMap.get(ip) || [];
  const recent = entry.filter(t => now - t < RATE_LIMIT_WINDOW_MS);
  recent.push(now);
  attemptMap.set(ip, recent);
  return recent.length > RATE_LIMIT_MAX;
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const ip = (req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown').split(',')[0].trim();
  if (isRateLimited(ip)) {
    res.status(429).json({ error: 'Kebanyakan percobaan, coba lagi sebentar lagi.' });
    return;
  }

  const sessionSecret = process.env.SESSION_SECRET;
  if (!sessionSecret) {
    res.status(500).json({ error: 'SESSION_SECRET belum diset di Environment Variables Vercel.' });
    return;
  }

  const { username, password } = req.body || {};
  if (typeof username !== 'string' || username.length === 0 || typeof password !== 'string' || password.length === 0) {
    res.status(400).json({ error: 'Username dan password wajib diisi.' });
    return;
  }

  let db;
  try {
    db = getDb();
  } catch (e) {
    res.status(500).json({ error: e.message });
    return;
  }

  try {
    const usernameKey = username.toLowerCase();
    const userDoc = await db.collection('users').doc(usernameKey).get();

    if (!userDoc.exists) {
      res.status(401).json({ error: 'Username atau password salah.' });
      return;
    }

    const userData = userDoc.data();
    const match = verifyPassword(password, userData.passwordHash);

    if (!match) {
      res.status(401).json({ error: 'Username atau password salah.' });
      return;
    }

    res.setHeader('Set-Cookie', createSessionCookie(userData.username, sessionSecret));
    res.status(200).json({ ok: true, username: userData.username });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Gagal memverifikasi akun: ' + err.message });
  }
};
