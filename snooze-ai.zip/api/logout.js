module.exports = async function handler(req, res) {
  res.setHeader('Set-Cookie', 'snooze_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');
  res.status(200).json({ ok: true });
};
