// Vercel Edge Middleware — jalan SEBELUM halaman/API manapun diproses.
// Ini yang bikin login gate beneran ngunci semua halaman (bukan cuma tombol di frontend).
// Middleware ini SENDIRI tetap gak nyentuh database — cuma verifikasi tanda tangan
// HMAC pada cookie (stateless). Akun usernya yang disimpan di Firestore, dicek pas
// login/register di api/login.js & api/register.js, bukan di sini.

export const config = {
  matcher: ['/((?!api/login|api/register|api/logout|api/me|Login\\.html|Register\\.html|common\\.css|common\\.js).*)'],
};

function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
  }
  return bytes;
}

async function verifyToken(token, secret) {
  if (!token) return false;
  const parts = token.split('.');
  if (parts.length !== 3) return false;
  const [expiryStr, usernameB64, sigHex] = parts;
  const expiry = Number(expiryStr);
  if (!expiry || Date.now() > expiry) return false;

  try {
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']
    );
    const payload = `${expiryStr}.${usernameB64}`;
    return await crypto.subtle.verify('HMAC', key, hexToBytes(sigHex), enc.encode(payload));
  } catch (e) {
    return false;
  }
}

function getCookie(req, name) {
  const raw = req.headers.get('cookie') || '';
  const match = raw.match(new RegExp('(?:^|;\\s*)' + name + '=([^;]*)'));
  return match ? decodeURIComponent(match[1]) : null;
}

export default async function middleware(req) {
  const sessionSecret = process.env.SESSION_SECRET;

  // Kalau SESSION_SECRET belum diset, gate dianggap "off" — semua orang bisa akses.
  // Baru nyalain gate ini SETELAH Firebase + FIREBASE_SERVICE_ACCOUNT udah siap,
  // soalnya kalau SESSION_SECRET aktif tapi Firestore belum siap, login/register bakal gagal terus.
  if (!sessionSecret) {
    return;
  }

  const token = getCookie(req, 'snooze_session');
  const valid = await verifyToken(token, sessionSecret);

  if (!valid) {
    const url = new URL(req.url);
    const loginUrl = new URL('/Login.html', url.origin);
    loginUrl.searchParams.set('redirect', url.pathname + url.search);
    return Response.redirect(loginUrl, 302);
  }
}

