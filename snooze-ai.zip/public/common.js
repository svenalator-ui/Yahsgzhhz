// ---- Dipakai bersama oleh Home.html, Chat.html, Setting.html ----
const STORAGE_KEY = "snooze_ai_conversations";
const PREFS_KEY = "snooze_ai_prefs";
const PIN_KEY = "snooze_ai_pinned";
const DRAFT_KEY = "snooze_ai_draft";

function loadConversations(){
  try{ return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }catch(e){ return []; }
}
function saveConversationsList(list){
  try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(list)); }catch(e){}
}
function deleteAllConversations(){
  saveConversationsList([]);
}
function textOf(content){
  if(typeof content === 'string') return content;
  if(Array.isArray(content)){
    const t = content.find(c => c.type === 'text');
    return t ? t.text : '[gambar]';
  }
  return '';
}
function escapeHtml(s){
  const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML;
}
function timeAgo(ts){
  const diff = Date.now() - ts;
  const min = Math.floor(diff/60000);
  if(min < 1) return 'Baru saja';
  if(min < 60) return min + ' menit lalu';
  const hr = Math.floor(min/60);
  if(hr < 24) return hr + ' jam lalu';
  const day = Math.floor(hr/24);
  if(day < 7) return day + ' hari lalu';
  return new Date(ts).toLocaleDateString('id-ID', { day:'numeric', month:'short' });
}

// ---- Pin percakapan ----
function loadPinned(){
  try{ return JSON.parse(localStorage.getItem(PIN_KEY)) || []; }catch(e){ return []; }
}
function savePinned(list){
  try{ localStorage.setItem(PIN_KEY, JSON.stringify(list)); }catch(e){}
}
function togglePinned(id){
  const pinned = loadPinned();
  const i = pinned.indexOf(id);
  if(i === -1) pinned.push(id); else pinned.splice(i,1);
  savePinned(pinned);
  return pinned;
}

// ---- Daftar model gratis OpenRouter yang bisa dipilih ----
// Cuma "Snooze" (default) yang dikasih nama rebrand — model lain tampil dengan nama aslinya.
const MODEL_OPTIONS = [
  { key:'snooze',        label:'Snooze (default)' },
  { key:'gemini-flash',  label:'Gemini 2.0 Flash (free)' },
  { key:'llama-mini',    label:'Llama 3.1 8B (free)' },
  { key:'deepseek',      label:'DeepSeek R1 (free)' },
  { key:'qwen',          label:'Qwen 2.5 72B (free)' }

];

// ---- Preferensi (tersimpan lokal di browser) ----
function loadPrefs(){
  const defaults = { voiceLang:'id-ID', fontSize:'normal', themeColor:'default', displayMode:'dark', modelKey:'snooze' };
  try{ return Object.assign(defaults, JSON.parse(localStorage.getItem(PREFS_KEY)) || {}); }
  catch(e){ return defaults; }
}
function savePrefs(prefs){
  try{ localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); }catch(e){}
}

const THEME_COLORS = {
  default:{ accent:'#ffffff' },
  purple:{ accent:'#a78bfa' },
  cyan:{ accent:'#22d3ee' },
  rose:{ accent:'#fb7185' },
  amber:{ accent:'#fbbf24' },
  green:{ accent:'#34d399' },
};

// Terapkan preferensi (tema, font, warna aksen) ke halaman saat ini — panggil di tiap halaman saat load
function applyPrefs(){
  const prefs = loadPrefs();
  document.body.classList.toggle('light-mode', prefs.displayMode === 'light');
  document.body.classList.remove('font-small','font-large');
  if(prefs.fontSize !== 'normal') document.body.classList.add('font-' + prefs.fontSize);
  const color = THEME_COLORS[prefs.themeColor] || THEME_COLORS.default;
  document.documentElement.style.setProperty('--accent', color.accent);
  return prefs;
}

// ---- Membuat percakapan baru & membawa pesan pertama ke Chat.html ----
function startNewChatWithText(text){
  const id = 'c_' + Date.now() + '_' + Math.random().toString(36).slice(2,7);
  sessionStorage.setItem('snooze_pending_start', JSON.stringify({ id, text: text || '' }));
  window.location.href = 'Chat.html?id=' + id + (text ? '&autosend=1' : '');
}
function goToChat(id){
  window.location.href = 'Chat.html?id=' + encodeURIComponent(id);
}

// ---- Menu utama (navigasi + peraturan + info user) — dipakai di semua halaman ----
const APP_NAV_ITEMS = [
  { page:'Home',    href:'Home.html',    label:'Home',
    icon:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>' },
  { page:'Chat',    href:'Chat.html',    label:'Chat',
    icon:'<path d="M21 11.5a8.4 8.4 0 0 1-8.8 8.5 9 9 0 0 1-3.6-.7L3 21l1.7-5.6A8.4 8.4 0 0 1 21 11.5z"/>' },
  { page:'Setting', href:'Setting.html', label:'Settings',
    icon:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6V21a2 2 0 1 1-4 0v-.2a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.6-1H3a2 2 0 1 1 0-4h.2a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.6V3a2 2 0 1 1 4 0v.2a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.6 1H21a2 2 0 1 1 0 4h-.2a1.7 1.7 0 0 0-1.5 1z"/>' }
];

const APP_RULES = [
  'Jangan pakai Snooze AI buat hal ilegal, nyebar hoax, atau nyakitin orang lain.',
  'Jangan share akun kamu ke orang lain — satu akun buat satu orang.',
  'Jangan spam request berlebihan biar kuota model gratis tetep kepake adil buat semua.',
  'Riwayat chat kamu cuma tersimpan di HP/browser kamu sendiri, gak disinkron ke server.',
  'Snooze AI bisa aja salah jawab — selalu double-check info penting.',
  'Pemilik app berhak nonaktifin akun yang melanggar aturan di atas.'
];

function renderMenuNavHtml(activePage){
  return APP_NAV_ITEMS.map(item => `
    <a class="menu-nav-item${item.page===activePage?' active':''}" href="${item.href}">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">${item.icon}</svg>
      <span>${item.label}</span>
    </a>`).join('');
}

function openRulesModal(){
  let modal = document.getElementById('rulesModal');
  if(!modal){
    modal = document.createElement('div');
    modal.id = 'rulesModal';
    modal.className = 'rules-modal-overlay';
    modal.onclick = (e) => { if(e.target === modal) closeRulesModal(); };
    modal.innerHTML = `
      <div class="rules-modal">
        <h3>Peraturan Pemakaian</h3>
        <div class="sub">Baca dulu sebelum lanjut pakai Snooze AI</div>
        <ol>${APP_RULES.map(r => `<li>${escapeHtml(r)}</li>`).join('')}</ol>
        <button onclick="closeRulesModal()">Oke, Ngerti</button>
      </div>`;
    document.body.appendChild(modal);
  }
  modal.classList.add('show');
}
function closeRulesModal(){
  const modal = document.getElementById('rulesModal');
  if(modal) modal.classList.remove('show');
}

async function fetchMe(){
  try{
    const res = await fetch('/api/me');
    const data = await res.json();
    return data;
  }catch(e){
    return { loggedIn:false };
  }
}

async function logoutUser(){
  if(!confirm('Yakin mau keluar?')) return;
  try{ await fetch('/api/logout', { method:'POST' }); }catch(e){}
  window.location.replace('Login.html');
}

function openAppMenu(){
  let overlay = document.getElementById('appMenuOverlay');
  if(!overlay){
    overlay = document.createElement('div');
    overlay.id = 'appMenuOverlay';
    overlay.className = 'app-menu-overlay';
    overlay.onclick = (e) => { if(e.target === overlay) closeAppMenu(); };
    overlay.innerHTML = `
      <div class="app-menu-drawer">
        <div class="app-menu-header">
          <svg class="logo-mark" viewBox="0 0 24 24" fill="currentColor"><path d="M4 20L14 4l2 6-8 10H4z"/><path d="M12 20l6-9 2 5-4 4h-4z" opacity="0.55"/></svg>
          <span>Snooze AI</span>
        </div>
        <div class="app-menu-body">
          ${renderMenuNavHtml(document.body.getAttribute('data-page'))}
          <div class="menu-divider"></div>
          <button class="menu-rules-btn" onclick="openRulesModal()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><path d="M14 2v6h6"/><path d="M9 13h6M9 17h6"/></svg>
            Peraturan
          </button>
        </div>
        <div class="app-menu-footer" id="appMenuUserSection">
          <div class="menu-user-sub" style="padding:8px 4px;">Memuat...</div>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    renderMenuUserSection('appMenuUserSection');
  }
  overlay.classList.add('open');
}
function closeAppMenu(){
  const overlay = document.getElementById('appMenuOverlay');
  if(overlay) overlay.classList.remove('open');
}
async function renderMenuUserSection(containerId){
  const el = document.getElementById(containerId);
  if(!el) return;
  const me = await fetchMe();
  if(me.loggedIn){
    el.innerHTML = `
      <div class="menu-user-card">
        <div class="menu-user-avatar">${escapeHtml((me.username||'?').charAt(0).toUpperCase())}</div>
        <div>
          <div class="menu-user-name">${escapeHtml(me.username)}</div>
          <div class="menu-user-sub">Masuk sebagai user</div>
        </div>
      </div>
      <button class="menu-logout-btn" onclick="logoutUser()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>
        Keluar
      </button>`;
  } else {
    el.innerHTML = `
      <a class="menu-logout-btn" href="Login.html" style="text-decoration:none;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/></svg>
        Masuk / Daftar
      </a>`;
  }
}

