# Snooze AI

Chatbot AI pakai OpenRouter (model gratis). Model default dinamain **"Snooze"** — model lain yang bisa dipilih tampil dengan nama aslinya (Gemini, Llama, DeepSeek, Qwen). API key & system prompt disimpan sebagai Environment Variable di Vercel — **tidak pernah ada di kode atau file yang di-upload**.

## Struktur folder
```
snooze-ai/
├── public/              ← semua file statis (yang dibuka lewat browser)
│   ├── index.html       ← redirect ke Home.html
│   ├── Login.html        masuk pakai akun (cuma aktif kalau env-nya diisi)
│   ├── Register.html     daftar akun baru
│   ├── Home.html         landing page: sapaan, saran pertanyaan, chat terakhir
│   ├── Chat.html         halaman obrolan penuh
│   ├── Setting.html      model, tampilan, kelola riwayat
│   ├── common.css        style bersama semua halaman (termasuk menu drawer)
│   └── common.js         logic bersama semua halaman
├── api/                 ← serverless functions (backend)
│   ├── chat.js           proxy streaming ke OpenRouter
│   ├── login.js           verifikasi akun ke Firestore
│   ├── register.js        bikin akun baru di Firestore
│   ├── logout.js          hapus cookie session
│   └── me.js              baca siapa yang lagi login (buat sidebar)
├── lib/                 ← helper yang dipakai bareng oleh file di api/
│   ├── firebase.js        koneksi ke Firestore
│   ├── password.js        hashing password (scrypt, bawaan Node)
│   └── session.js         bikin & verifikasi cookie session
├── middleware.js        ← cek login gateway di SETIAP request (harus di root)
├── package.json
├── vercel.json
└── .env.example
```

`public/` itu folder standar Vercel buat file statis — semua isinya otomatis di-serve langsung di root domain (`punyakamu.vercel.app/Home.html`, dst), gak perlu setting tambahan. `api/` dan `middleware.js` **wajib** tetap di root project (di luar `public/`), itu aturan Vercel buat serverless function & middleware.

## Navigasi

Gak ada bottom nav lagi — navigasi sekarang lewat **menu hamburger (☰)** di kiri atas tiap halaman. Isinya:
- Link ke Home / Chat / Settings
- **Peraturan** — daftar aturan pakai app (bisa diedit di `APP_RULES` dalam `common.js`)
- **Info user** — nama akun yang lagi login + tombol keluar (kalau belum login, jadi tombol "Masuk / Daftar")

Di halaman Chat, menu ini nyatu sama sidebar Riwayat yang udah ada (jadi satu hamburger buat semuanya).

## Login Gateway (register/login beneran, pakai Firestore)

Setiap orang bisa **daftar akun sendiri** (username + password) lewat `Register.html` — bukan lagi satu password bersama. Akun disimpan di **Firestore** (Firebase), password di-hash pakai scrypt sebelum disimpan (gak pernah nyimpen plain text). Setelah login, server kasih "tiket" (cookie) yang ditandatangani HMAC buat 7 hari — sesi ini sendiri tetap stateless/gak disimpan di server, cuma akunnya yang ada di database. Setiap request ke halaman manapun dicek ulang oleh `middleware.js` sebelum kontennya ditampilkan — jadi bener-bener ngunci semua halaman, bukan cuma tombol di frontend.

- **Aktifkan**: setup Firestore dulu (lihat bagian "Setup Firestore" di bawah), lalu isi `FIREBASE_SERVICE_ACCOUNT` dan `SESSION_SECRET` di Environment Variables Vercel
- **Nonaktifkan**: kosongkan `SESSION_SECRET` — app otomatis bisa diakses bebas lagi (gate dianggap "off")
- **Penting**: isi `SESSION_SECRET` PALING TERAKHIR, setelah `FIREBASE_SERVICE_ACCOUNT` beres — soalnya begitu `SESSION_SECRET` keisi, gate langsung aktif dan Login/Register butuh Firestore buat kerja. Kalau kebalik, semua orang termasuk kamu bisa kekunci
- Logout ada di Settings → Akun → Keluar

### Setup Firestore (sekali aja)

1. Buka https://console.firebase.google.com, bikin project baru
2. Sidebar → **Build → Firestore Database** → **Create database** → pilih lokasi terdekat → **Standard edition** → mode **production** → Enable
3. Ikon gear ⚙️ → **Project settings** → tab **Service accounts** → **Generate new private key** → download file `.json`-nya
4. Buka file `.json` itu, **copy SELURUH isinya**
5. Di Vercel: **Settings → Environment Variables**, bikin variable `FIREBASE_SERVICE_ACCOUNT`, paste seluruh isi JSON tadi sebagai value-nya
6. Generate `SESSION_SECRET` (string acak panjang, bebas — lihat contoh di `.env.example`), isi di Vercel juga
7. Redeploy (`vercel --prod`) — gate langsung aktif, dan halaman Register.html udah bisa dipakai daftar akun

## Fitur
**Chat & AI**
- Respons streaming real-time + format markdown
- **Mode Chat & Codex** — dua system prompt beda (obrolan santai vs jawaban teknis ringkas), tombol switch di atas kolom chat
- **Pilihan model** — Snooze (default) + beberapa model gratis OpenRouter lain, diatur di Settings
- Auto pindah ke model vision saat kirim gambar
- Kode dari AI tampil sebagai **file card** (klik buat buka preview full-screen). Kode HTML langsung bisa **di-preview live** (di-render beneran), kode lain tampil sebagai teks dengan syntax highlighting + tombol copy

**Lampiran**
- Upload gambar (vision)
- Upload dokumen: `.txt` `.md` `.csv` `.json` `.html` `.pdf` (PDF diparsing pakai pdf.js, isinya jadi konteks buat AI)

**Percakapan**
- Riwayat tersimpan di browser, bisa **pin**, **rename** (klik 2x judul), **cari** (ikon search di sidebar)
- Edit pesan lama → AI jawab ulang dari titik itu
- Regenerate jawaban, tombol stop saat AI ngetik
- Draft pesan otomatis tersimpan kalau belum sempat kirim
- Character counter
- Export per-chat (.md / .txt) atau semua chat sekaligus (dari Settings)
- Like/dislike/copy jawaban

**Tampilan (di Settings, berlaku di semua halaman)**
- Mode gelap/terang
- Ukuran teks (kecil/normal/besar)
- Warna aksen (putih/ungu/cyan/pink/kuning/hijau)

**Lainnya**
- Voice input asli (Web Speech API browser, pilih bahasa Indonesia/English)
- Rate limit dasar di server (20 request/menit per IP)

## Cara Deploy ke Vercel (drag & drop, TANPA git repo)

1. Install Vercel CLI (sekali aja):
   ```
   npm install -g vercel
   ```
2. Buka terminal di folder `snooze-ai`, jalankan:
   ```
   vercel
   ```
3. Setelah project jadi di dashboard Vercel, buka **Settings → Environment Variables**, isi minimal:
   | Key | Value |
   |---|---|
   | `BATU_BATA` | key dari https://openrouter.ai/keys |

   Login gateway (opsional, isi kalau mau app-nya pakai sistem akun — lihat "Setup Firestore" di atas dulu):
   | Key | Value |
   |---|---|
   | `FIREBASE_SERVICE_ACCOUNT` | seluruh isi file JSON service account Firebase |
   | `SESSION_SECRET` | string acak panjang, bebas, buat tanda tangan cookie session — isi ini PALING TERAKHIR |

   Opsional (kalau mau override default):
   | Key | Keterangan |
   |---|---|
   | `OPENROUTER_MODEL` | model untuk "Snooze" (default: `openrouter/free` — router otomatis OpenRouter, lebih tahan rate limit) |
   | `OPENROUTER_MODEL_GEMINI` | default: `google/gemini-2.0-flash-exp:free` |
   | `OPENROUTER_MODEL_LLAMA_MINI` | default: `meta-llama/llama-3.1-8b-instruct:free` |
   | `OPENROUTER_MODEL_DEEPSEEK` | default: `deepseek/deepseek-r1:free` |
   | `OPENROUTER_MODEL_QWEN` | default: `qwen/qwen-2.5-72b-instruct:free` |
   | `OPENROUTER_VISION_MODEL` | default: `meta-llama/llama-3.2-11b-vision-instruct:free` |
   | `SYSTEM_PROMPT` | system prompt mode Chat (ada default bawaan kalau kosong) |
   | `SYSTEM_PROMPT_CODEX` | system prompt mode Codex (ada default bawaan kalau kosong) |
4. Deploy ulang: `vercel --prod`
5. Buka link `https://nama-project-kamu.vercel.app`

**Alternatif tanpa CLI:** buka https://vercel.com/new, drag folder `snooze-ai` (atau zip-nya) ke area upload.

## Testing lokal (opsional)
```
npm install -g vercel
vercel dev
```
Baca `.env.local` otomatis — salin dari `.env.example`.

## Catatan & batasan
- Riwayat chat hanya tersimpan di **browser itu doang** (localStorage) — pindah device/browser, riwayat gak ikut.
- Model gratis OpenRouter kadang berubah ketersediaannya — kalau ada model error "not found", cek daftar model `:free` terbaru di https://openrouter.ai/models dan update Environment Variable yang sesuai.
- Belum ada fitur pencarian/browsing internet (butuh API pencarian terpisah, di luar scope ini).
- Rate limit di server bersifat *best-effort* (in-memory per instance Vercel), cukup buat cegah spam ringan, bukan proteksi ketat.
- Voice input pakai Web Speech API browser — cuma jalan optimal di Chrome/Edge.
- Firestore Spark (free tier): 1GB storage, 50rb baca/20rb tulis per hari — buat sistem akun doang, jauh dari bakal kesentuh (muat ratusan ribu akun).
- Belum ada fitur "lupa password" — kalau lupa, buat akun baru aja lewat Register.html, atau hapus manual dokumennya di Firestore Console (collection `users`).
- Riwayat chat TETAP di localStorage per-device (belum ikut disinkron ke akun/Firestore) — itu peningkatan terpisah kalau nanti dibutuhkan.
